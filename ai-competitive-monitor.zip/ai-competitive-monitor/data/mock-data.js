/**
 * 模拟数据生成器
 * 生成逼真的电商竞品数据，包含每日变化（价格、销量、评价等）
 */

const shops = [
  { id: "shop_001", name: "美的官方旗舰店", level: "旗舰店", followers: 1280000 },
  { id: "shop_002", name: "苏泊尔厨房电器专营", level: "专营店", followers: 456000 },
  { id: "shop_003", name: "九阳生活电器旗舰店", level: "旗舰店", followers: 890000 },
  { id: "shop_004", name: "小熊创意厨房旗舰店", level: "旗舰店", followers: 670000 },
  { id: "shop_005", name: "摩飞电器旗舰店", level: "旗舰店", followers: 320000 },
];

const productPool = [
  { name: "破壁料理机", basePrice: 399, baseSales: 8200 },
  { name: "空气炸锅", basePrice: 299, baseSales: 15600 },
  { name: "多功能电煮锅", basePrice: 159, baseSales: 22000 },
  { name: "迷你电饭煲", basePrice: 199, baseSales: 18500 },
  { name: "全自动豆浆机", basePrice: 349, baseSales: 6800 },
  { name: "家用绞肉机", basePrice: 129, baseSales: 11000 },
  { name: "电热水壶", basePrice: 89, baseSales: 35000 },
  { name: "早餐机", basePrice: 259, baseSales: 9200 },
  { name: "养生壶", basePrice: 179, baseSales: 14000 },
  { name: "便携榨汁杯", basePrice: 69, baseSales: 28000 },
  { name: "电蒸锅", basePrice: 229, baseSales: 7500 },
  { name: "面包机", basePrice: 319, baseSales: 5200 },
];

// 生成随机波动
function jitter(base, pct) {
  const delta = base * pct;
  return Math.round((base + (Math.random() * 2 - 1) * delta) * 100) / 100;
}

function pickRandom(arr, n) {
  const shuffled = [...arr].sort(() => Math.random() - 0.5);
  return shuffled.slice(0, n);
}

/**
 * 生成某一天的竞品快照数据
 */
export function generateDailySnapshot(dateStr) {
  const snapshot = { date: dateStr, shops: [] };

  for (const shop of shops) {
    const products = pickRandom(productPool, 6).map((p, i) => {
      const price = jitter(p.basePrice, 0.15);
      const yesterdaySales = jitter(p.baseSales, 0.2);
      const todaySales = jitter(yesterdaySales, 0.1);
      const rating = jitter(4.5, 0.06);
      const reviewCount = jitter(p.baseSales * 3, 0.25);
      const negativeReviewRate = jitter(0.05, 0.6);

      // 模拟一些"事件"
      const events = [];
      if (Math.random() < 0.15) {
        events.push({
          type: "price_drop",
          detail: `价格从¥${jitter(price, 0.2)}降至¥${price}`,
        });
      }
      if (Math.random() < 0.1) {
        events.push({ type: "new_product", detail: "新上架商品" });
      }
      if (Math.random() < 0.08) {
        events.push({
          type: "review_spike",
          detail: "近3天差评数量异常增加",
        });
      }
      if (Math.random() < 0.12) {
        events.push({
          type: "promotion",
          detail: "参与平台满减活动",
        });
      }

      return {
        id: `${shop.id}_p${i}`,
        name: `${shop.name.replace(/旗舰店|专营/, "")} ${p.name}`,
        price: Math.round(price * 100) / 100,
        yesterdaySales: Math.round(yesterdaySales),
        todaySales: Math.round(todaySales),
        salesChange: Math.round(((todaySales - yesterdaySales) / yesterdaySales) * 100),
        rating: Math.min(5, Math.max(1, Math.round(rating * 10) / 10)),
        reviewCount: Math.round(reviewCount),
        negativeReviewRate: Math.round(negativeReviewRate * 1000) / 10,
        events,
      };
    });

    snapshot.shops.push({
      ...shop,
      products,
    });
  }

  return snapshot;
}

/**
 * 生成Demo模式下的AI分析结果（模拟大模型输出）
 */
export function generateDemoAnalysis(snapshot) {
  // 汇总关键指标
  let totalProducts = 0;
  let priceDrops = 0;
  let newProducts = 0;
  let reviewIssues = 0;
  let hotProducts = [];

  for (const shop of snapshot.shops) {
    for (const p of shop.products) {
      totalProducts++;
      if (p.events.some((e) => e.type === "price_drop")) priceDrops++;
      if (p.events.some((e) => e.type === "new_product")) newProducts++;
      if (p.events.some((e) => e.type === "review_spike")) reviewIssues++;
      if (p.salesChange > 5) {
        hotProducts.push({
          name: p.name,
          change: p.salesChange,
          shop: shop.name,
        });
      }
    }
  }

  hotProducts.sort((a, b) => b.change - a.change);
  hotProducts = hotProducts.slice(0, 5);

  return {
    summary: `今日共监控${snapshot.shops.length}家店铺、${totalProducts}款商品。发现${priceDrops}款商品降价、${newProducts}款新品上架、${reviewIssues}款商品出现差评异常。`,
    highlights: [
      `🔥 ${hotProducts.length}款商品销量逆势增长超过5%，其中"${hotProducts[0]?.name}"涨幅最大（+${hotProducts[0]?.change}%）`,
      `💰 ${priceDrops}款商品出现降价，可能与平台大促预热有关，建议关注价格策略`,
      `🆕 ${newProducts}款新品上架，重点关注上新节奏较快的店铺`,
      `⚠️ ${reviewIssues}款商品差评异常，建议排查产品质量或物流问题`,
    ],
    recommendations: [
      "重点关注销量增长Top3商品的卖点提炼，用于自身商品优化",
      "针对降价商品，评估是否需要跟进价格策略或差异化竞争",
      "新品上架的店铺值得深入研究其选品逻辑和上新节奏",
      "差评异常商品可作为选品避坑参考",
    ],
    hotProducts,
  };
}
