/**
 * AI竞品监控日报 - 配置文件
 * 修改这里来切换AI模型、设置监控品类等
 */

export default {
  // AI模式: "demo"(无需API) | "openai" | "tongyi"(通义千问)
  aiMode: process.env.AI_MODE || "demo",

  // OpenAI配置
  openai: {
    apiKey:  process.env.DASHSCOPE_API_KEY || "",
    model: "gpt-4o-mini",
  },

  // 通义千问配置 (阿里云DashScope)
  tongyi: {
    apiKey: process.env.DASHSCOPE_API_KEY || "",
    model: "qwen-plus",
    baseUrl: "https://dashscope.aliyuncs.com/compatible-mode/v1",
  },

  // 监控配置
  monitor: {
    // 监控品类
    categories: ["厨房小家电"],
    // 每个品类监控的店铺数
    shopCount: 5,
    // 每个店铺监控的商品数
    productCount: 10,
  },

  // 报告输出目录
  reportDir: "./reports",

  // 飞书群机器人Webhook地址（移到这里面）
  // 飞书群机器人Webhook地址
feishu: {
  webhook: process.env.FEISHU_WEBHOOK || "",
},
};
