﻿# AI竞品监控日报

> 用AI自动监控电商竞品动态，每日生成智能分析报告，推送到飞书群。

## 解决什么问题

供应链运营每天要花1-2小时手动盯竞品：谁降价了、谁上新品了、谁卖爆了、谁被差评淹没了。这件事重复、枯燥、容易漏掉关键信号。

这个工具把整个流程自动化了：**数据采集 → AI分析 → 报告生成 → 飞书推送**，全程无需人工干预。

## 功能特性

- **竞品数据采集** - 自动抓取多店铺、多商品的销售、价格、评价数据
- **AI智能分析** - 支持三种模式：Demo演示 / OpenAI GPT / 通义千问
- **可视化报告** - 生成精美HTML日报，含图表、关键发现、行动建议
- **飞书推送** - 自动将日报推送到飞书群，团队实时可见
- **异常监控** - 自动识别降价、新品上架、差评飙升等异常信号

## 技术栈

- 运行时: Node.js (ES Modules)
- AI引擎: OpenAI API / 阿里云DashScope (通义千问)
- 可视化: Chart.js
- 推送: 飞书群机器人Webhook

## 快速开始

### 1. 安装依赖

```
cd ai-competitive-monitor
npm install
```

### 2. 运行Demo模式（无需API Key）

```
node src/index.js --mode demo
```

### 3. 使用真实AI分析

方式A：通义千问（推荐，阿里系）

```
$env:DASHSCOPE_API_KEY="你的Key"
$env:AI_MODE="tongyi"
node src/index.js
```

方式B：OpenAI

```
$env:OPENAI_API_KEY="你的Key"
$env:AI_MODE="openai"
node src/index.js
```

### 4. 推送到飞书

```
$env:FEISHU_WEBHOOK="你的飞书Webhook地址"
node src/index.js --mode demo
```

## 项目结构

```
ai-competitive-monitor/
├── config.js              # 配置文件（AI模式、监控品类、飞书Webhook）
├── data/
│   └── mock-data.js       # 模拟数据生成器
├── src/
│   ├── analyzer.js        # AI分析模块（支持Demo/OpenAI/通义千问）
│   ├── reporter.js        # HTML报告生成器（含Chart.js图表）
│   ├── notifier.js        # 飞书推送模块
│   ├── scraper.js         # 数据爬虫（扩展用）
│   └── index.js           # 主入口
├── reports/               # 生成的日报存放目录
├── package.json
└── README.md
```

## AI模式对比

| 模式 | 说明 | 适用场景 |
|------|------|----------|
| demo | 内置规则模拟分析 | 快速演示、无API Key时 |
| openai | 调用GPT-4o-mini | 英文场景、通用分析 |
| tongyi | 调用通义千问 | 中文电商场景（推荐） |

## 扩展方向

- 接入真实数据源（1688 API / 爬虫）
- 历史趋势对比（7天/30天变化）
- 定时任务（每日自动运行）
- 更多推送渠道（微信、钉钉）
- 数据库存储历史数据

## 作者

这是一个AI驱动的供应链竞品监控原型项目，展示了如何用AI重塑重复性业务流程。
