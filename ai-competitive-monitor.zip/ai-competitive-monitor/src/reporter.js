/**
 * 日报生成器 - 输出精美的HTML报告
 */
import { writeFileSync, mkdirSync, existsSync, copyFileSync } from "node:fs";
import { join } from "node:path";
import { tmpdir } from "node:os";
import config from "../config.js";

function esc(str) {
  return String(str).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

function buildShopCards(snapshot) {
  return snapshot.shops
    .map((shop) => {
      const rows = shop.products
        .map((p) => {
          const changeClass = p.salesChange >= 0 ? "up" : "down";
          const changeSign = p.salesChange >= 0 ? "+" : "";
          const eventTags = p.events
            .map((e) => {
              const colors = { price_drop: "#e74c3c", new_product: "#3498db", review_spike: "#e67e22", promotion: "#2ecc71" };
              return `<span class="tag" style="background:${colors[e.type] || "#95a5a6"}">${esc(e.detail)}</span>`;
            })
            .join(" ");
          return `<tr>
            <td>${esc(p.name)}</td>
            <td>¥${p.price}</td>
            <td>${p.todaySales.toLocaleString()}</td>
            <td class="${changeClass}">${changeSign}${p.salesChange}%</td>
            <td>${p.rating}</td>
            <td>${p.negativeReviewRate}%</td>
            <td>${eventTags || "-"}</td>
          </tr>`;
        })
        .join("\n");

      return `
      <div class="shop-card">
        <h3>${esc(shop.name)} <span class="badge">${esc(shop.level)}</span> <span class="followers">粉丝 ${(shop.followers / 10000).toFixed(1)}万</span></h3>
        <table>
          <thead>
            <tr><th>商品</th><th>价格</th><th>今日销量</th><th>环比</th><th>评分</th><th>差评率</th><th>事件</th></tr>
          </thead>
          <tbody>${rows}</tbody>
        </table>
      </div>`;
    })
    .join("\n");
}

export function generateReport(snapshot, analysis) {
  const shopCards = buildShopCards(snapshot);
  const highlights = (analysis.highlights || []).map((h) => `<li>${esc(h)}</li>`).join("\n");
  const recommendations = (analysis.recommendations || []).map((r) => `<li>${esc(r)}</li>`).join("\n");
  const hotRows = (analysis.hotProducts || [])
    .map((h) => `<tr><td>${esc(h.name)}</td><td>${esc(h.shop)}</td><td class="up">+${h.change}%</td></tr>`)
    .join("\n");

  const html = `<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>AI竞品监控日报 - ${snapshot.date}</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", "Microsoft YaHei", sans-serif; background: #f0f2f5; color: #1a1a2e; line-height: 1.6; }
  .container { max-width: 1200px; margin: 0 auto; padding: 24px; }
  .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 32px; border-radius: 12px; margin-bottom: 24px; }
  .header h1 { font-size: 28px; margin-bottom: 8px; }
  .header .subtitle { opacity: 0.85; font-size: 14px; }
  .summary-card { background: white; border-radius: 12px; padding: 24px; margin-bottom: 24px; box-shadow: 0 2px 8px rgba(0,0,0,0.06); }
  .summary-card h2 { font-size: 18px; margin-bottom: 16px; color: #333; border-left: 4px solid #667eea; padding-left: 12px; }
  .summary-text { font-size: 15px; color: #555; margin-bottom: 16px; }
  .two-col { display: grid; grid-template-columns: 1fr 1fr; gap: 24px; margin-bottom: 24px; }
  .two-col .summary-card { margin-bottom: 0; }
  .two-col ul { list-style: none; padding: 0; }
  .two-col li { padding: 8px 0; border-bottom: 1px solid #f0f0f0; font-size: 14px; }
  .two-col li:last-child { border-bottom: none; }
  .shop-card { background: white; border-radius: 12px; padding: 24px; margin-bottom: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.06); }
  .shop-card h3 { font-size: 16px; margin-bottom: 16px; color: #333; }
  .badge { background: #e8eaf6; color: #3f51b5; padding: 2px 8px; border-radius: 4px; font-size: 12px; font-weight: normal; }
  .followers { color: #999; font-size: 12px; margin-left: 8px; }
  table { width: 100%; border-collapse: collapse; font-size: 13px; }
  th { background: #fafafa; padding: 10px 12px; text-align: left; font-weight: 600; color: #666; border-bottom: 2px solid #eee; }
  td { padding: 10px 12px; border-bottom: 1px solid #f5f5f5; }
  tr:hover { background: #f8f9ff; }
  .up { color: #e74c3c; font-weight: 600; }
  .down { color: #27ae60; font-weight: 600; }
  .tag { display: inline-block; padding: 2px 6px; border-radius: 3px; color: white; font-size: 11px; margin: 1px 0; }
  .hot-table td, .hot-table th { padding: 8px 12px; }
  .footer { text-align: center; color: #aaa; font-size: 12px; margin-top: 32px; padding: 16px; }
  .chart-row { display: grid; grid-template-columns: 1fr 1fr; gap: 24px; margin-bottom: 24px; }
  .chart-box { background: white; border-radius: 12px; padding: 24px; box-shadow: 0 2px 8px rgba(0,0,0,0.06); }
  .chart-box h3 { font-size: 15px; margin-bottom: 16px; color: #333; }
  canvas { max-height: 280px; }
</style>
</head>
<body>
<div class="container">
  <div class="header">
    <h1>📊 AI竞品监控日报</h1>
    <div class="subtitle">${snapshot.date} | 品类：${config.monitor.categories.join(", ")} | 监控店铺：${snapshot.shops.length}家</div>
  </div>

  <div class="summary-card">
    <h2>📋 今日总览</h2>
    <p class="summary-text">${esc(analysis.summary)}</p>
  </div>

  <div class="two-col">
    <div class="summary-card">
      <h2>🔍 关键发现</h2>
      <ul>${highlights}</ul>
    </div>
    <div class="summary-card">
      <h2>💡 行动建议</h2>
      <ul>${recommendations}</ul>
    </div>
  </div>

  ${hotRows ? `
  <div class="summary-card">
    <h2>🔥 热销商品 Top 5</h2>
    <table class="hot-table">
      <thead><tr><th>商品</th><th>店铺</th><th>销量涨幅</th></tr></thead>
      <tbody>${hotRows}</tbody>
    </table>
  </div>` : ""}

  <div class="chart-row">
    <div class="chart-box">
      <h3>各店铺总销量对比</h3>
      <canvas id="shopSalesChart"></canvas>
    </div>
    <div class="chart-box">
      <h3>商品价格分布</h3>
      <canvas id="priceDistChart"></canvas>
    </div>
  </div>
  <div class="summary-card">
    <h3>销量变化分布</h3>
    <canvas id="salesChangeChart" style="max-height:220px"></canvas>
  </div>

  ${shopCards}

  <div class="footer">
    AI竞品监控日报 · 由 AI 自动生成 · ${new Date().toLocaleString("zh-CN")}
  </div>
  </div>

<script>
// 店铺销量柱状图
new Chart(document.getElementById('shopSalesChart'), {
  type: 'bar',
  data: {
    labels: ${JSON.stringify(snapshot.shops.map(s => s.name.slice(0, 6)))},
    datasets: [{
      label: '今日总销量',
      data: ${JSON.stringify(snapshot.shops.map(s => s.products.reduce((a, p) => a + p.todaySales, 0)))},
      backgroundColor: ['#667eea','#764ba2','#f093fb','#4facfe','#00f2fe'],
      borderRadius: 6
    }]
  },
  options: { responsive: true, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true } } }
});

// 价格分布饼图
new Chart(document.getElementById('priceDistChart'), {
  type: 'doughnut',
  data: {
    labels: ['0-100元','100-200元','200-300元','300-400元','400元以上'],
    datasets: [{
      data: [
        ${JSON.stringify(snapshot.shops.flatMap(s => s.products).filter(p => p.price < 100).length)},
        ${JSON.stringify(snapshot.shops.flatMap(s => s.products).filter(p => p.price >= 100 && p.price < 200).length)},
        ${JSON.stringify(snapshot.shops.flatMap(s => s.products).filter(p => p.price >= 200 && p.price < 300).length)},
        ${JSON.stringify(snapshot.shops.flatMap(s => s.products).filter(p => p.price >= 300 && p.price < 400).length)},
        ${JSON.stringify(snapshot.shops.flatMap(s => s.products).filter(p => p.price >= 400).length)}
      ],
      backgroundColor: ['#667eea','#764ba2','#f093fb','#4facfe','#00f2fe']
    }]
  },
  options: { responsive: true, plugins: { legend: { position: 'bottom' } } }
});

// 销量变化分布图
(() => {
  const changes = ${JSON.stringify(snapshot.shops.flatMap(s => s.products).map(p => p.salesChange))};
  const buckets = {'<-10%':0, '-10~0%':0, '0~5%':0, '5~10%':0, '>10%':0};
  changes.forEach(c => {
    if (c < -10) buckets['<-10%']++;
    else if (c < 0) buckets['-10~0%']++;
    else if (c <= 5) buckets['0~5%']++;
    else if (c <= 10) buckets['5~10%']++;
    else buckets['>10%']++;
  });
  new Chart(document.getElementById('salesChangeChart'), {
    type: 'bar',
    data: {
      labels: Object.keys(buckets),
      datasets: [{ label: '商品数量', data: Object.values(buckets), backgroundColor: '#667eea', borderRadius: 6 }]
    },
    options: { responsive: true, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, ticks: { stepSize: 1 } } } }
  });
})();
</script>
</body>
</html>`;

  // 写入文件
  const filename = `report-${snapshot.date}.html`;
  const tmpDir = join(tmpdir(), "ai-competitive-monitor");
  if (!existsSync(tmpDir)) mkdirSync(tmpDir, { recursive: true });
  const tmpPath = join(tmpDir, filename);
  writeFileSync(tmpPath, html, "utf-8");

  // 尝试复制到项目目录
  let finalPath = tmpPath;
  try {
    if (!existsSync(config.reportDir)) mkdirSync(config.reportDir, { recursive: true });
    const projectPath = join(config.reportDir, filename);
    copyFileSync(tmpPath, projectPath);
    finalPath = projectPath;
  } catch {
    // 项目目录不可写时，报告保留在临时目录
  }
  return finalPath;
}
