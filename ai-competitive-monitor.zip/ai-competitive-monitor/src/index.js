/**
 * AI竞品监控日报 - 主入口
 *
 * 用法：
 *   node src/index.js                # 使用config中的默认模式
 *   node src/index.js --mode demo    # 强制Demo模式
 *   AI_MODE=openai node src/index.js # 使用OpenAI
 */
import { generateDailySnapshot } from "../data/mock-data.js";
import { analyze } from "./analyzer.js";
import { generateReport } from "./reporter.js";

// 解析命令行参数
const args = process.argv.slice(2);
const modeIdx = args.indexOf("--mode");
if (modeIdx !== -1 && args[modeIdx + 1]) {
  const { default: config } = await import("../config.js");
  config.aiMode = args[modeIdx + 1];
}

async function main() {
  console.log("╔══════════════════════════════════════╗");
  console.log("║     📊 AI竞品监控日报 v1.0          ║");
  console.log("╚══════════════════════════════════════╝");
  console.log();

  // 1. 生成/采集数据
  const today = new Date().toISOString().split("T")[0];
  console.log(`📡 [1/3] 采集竞品数据 (${today})...`);
  const snapshot = generateDailySnapshot(today);
  let totalProducts = 0;
  for (const shop of snapshot.shops) totalProducts += shop.products.length;
  console.log(`  ✅ 已获取 ${snapshot.shops.length} 家店铺、${totalProducts} 款商品数据`);

  // 2. AI分析
  console.log(`\n🤖 [2/3] AI智能分析中...`);
  const analysis = await analyze(snapshot);
  console.log("  ✅ 分析完成");

  // 3. 生成报告
  console.log(`\n📝 [3/3] 生成日报...`);
  const reportPath = generateReport(snapshot, analysis);
  console.log(`  ✅ 报告已生成: ${reportPath}`);

  // 打印摘要
  console.log("\n" + "─".repeat(50));
  console.log("📋 今日总览：");
  console.log(`  ${analysis.summary}`);
  console.log("\n🔍 关键发现：");
  for (const h of analysis.highlights || []) console.log(`  ${h}`);
  console.log("\n💡 行动建议：");
  for (const r of analysis.recommendations || []) console.log(`  ${r}`);
  console.log("─".repeat(50));
  console.log(`\n🎉 完成！请在浏览器中打开 ${reportPath} 查看完整报告`);

  // 4. 推送到飞书
  const webhook = config.feishu?.webhook;
  if (webhook) {
    console.log("\n📤 [4/4] 推送到飞书...");
    await sendFeishu(webhook, analysis, reportPath, snapshot);
  } else {
    console.log("\n💡 提示: 设置 FEISHU_WEBHOOK 环境变量即可自动推送到飞书群");
  }
}

main().catch((err) => {
  console.error("\n❌ 运行出错:", err.message);
  process.exit(1);
});
import { sendFeishu } from "./notifier.js";
import config from "../config.js";
