/**
 * 1688商品数据爬虫
 * 用法: node src/scraper.js "厨房小家电"
 */
import { writeFileSync, existsSync, mkdirSync } from "node:fs";
import { join } from "node:path";

const SEARCH_URL = "https://s.1688.com/selloffer/offer_search.htm";

const HEADERS = {
  "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
  "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
  "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
  "Referer": "https://www.1688.com/",
};

function extractProducts(html) {
  const products = [];
  // 匹配商品标题
  const titleRegex = /<a[^>]*class="[^"]*offer-title[^"]*"[^>]*title="([^"]+)"/g;
  // 匹配价格
  const priceRegex = /<span[^>]*class="[^"]*price[^"]*"[^>]*>([\d.]+)<\/span>/g;
  // 匹配销量
  const salesRegex = /<span[^>]*class="[^"]*sale[^"]*"[^>]*>(\d+[\d万]*)<\/span>/g;

  let titleMatch, priceMatch, salesMatch;
  const titles = [], prices = [], sales = [];

  while ((titleMatch = titleRegex.exec(html)) !== null) titles.push(titleMatch[1]);
  while ((priceMatch = priceRegex.exec(html)) !== null) prices.push(parseFloat(priceMatch[1]));
  while ((salesMatch = salesRegex.exec(html)) !== null) sales.push(salesMatch[1]);

  for (let i = 0; i < Math.min(titles.length, 20); i++) {
    products.push({
      name: titles[i],
      price: prices[i] || 0,
      sales: sales[i] || "未知",
    });
  }
  return products;
}

async function scrape(keyword) {
  const url = `${SEARCH_URL}?keywords=${encodeURIComponent(keyword)}`;
  console.log(`🔍 正在搜索: ${keyword}`);
  console.log(`📡 请求地址: ${url}\n`);

  try {
    const res = await fetch(url, { headers: HEADERS, redirect: "follow" });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const html = await res.text();

    const products = extractProducts(html);
    if (products.length === 0) {
      console.log("⚠️ 未抓取到商品，可能是反爬机制。请尝试手动录入或换个关键词。");
      return [];
    }

    console.log(`✅ 成功抓取 ${products.length} 个商品:\n`);
    products.forEach((p, i) => {
      console.log(`  ${i + 1}. ${p.name} | ¥${p.price} | 销量: ${p.sales}`);
    });
    return products;
  } catch (err) {
    console.error(`❌ 抓取失败: ${err.message}`);
    console.log("\n💡 1688有反爬机制，你可以:");
    console.log("  1. 换个关键词试试");
    console.log("  2. 手动从1688复制数据，我帮你格式化");
    console.log("  3. 使用模拟数据继续测试");
    return [];
  }
}

// 主入口
const keyword = process.argv[2] || "厨房小家电";
const products = await scrape(keyword);

if (products.length > 0) {
  const outDir = join(process.cwd(), "data");
  if (!existsSync(outDir)) mkdirSync(outDir, { recursive: true });
  const outPath = join(outDir, "scraped-data.json");
  writeFileSync(outPath, JSON.stringify(products, null, 2), "utf-8");
  console.log(`\n💾 数据已保存到: ${outPath}`);
}
