/**
 * 推送模块 - 支持飞书群机器人
 */
import config from "../config.js";

/**
 * 发送飞书消息
 * @param {string} webhook - 飞书Webhook地址
 * @param {object} analysis - AI分析结果
 * @param {string} reportPath - 报告文件路径
 * @param {object} snapshot - 当日数据快照
 */
export async function sendFeishu(webhook, analysis, reportPath, snapshot) {
  // 构建飞书富文本消息
  const shopSummary = snapshot.shops.map(shop => {
    const totalSales = shop.products.reduce((a, p) => a + p.todaySales, 0);
    return `${shop.name}: 总销量 ${totalSales.toLocaleString()}`;
  }).join("\n");

  const hotProducts = (analysis.hotProducts || []).slice(0, 3).map(h =>
    `  - ${h.name}（${h.shop}）+${h.change}%`
  ).join("\n");

  const body = {
    msg_type: "interactive",
    card: {
      header: {
        title: { tag: "plain_text", content: `📊 AI竞品监控日报 - ${snapshot.date}` },
        template: "purple"
      },
      elements: [
        {
          tag: "div",
          text: {
            tag: "lark_md",
            content: `**📋 今日总览**\n${analysis.summary}`
          }
        },
        { tag: "hr" },
        {
          tag: "div",
          text: {
            tag: "lark_md",
            content: `**🔍 关键发现**\n${(analysis.highlights || []).map(h => "• " + h).join("\n")}`
          }
        },
        { tag: "hr" },
        {
          tag: "div",
          text: {
            tag: "lark_md",
            content: `**🔥 热销Top 3**\n${hotProducts || "暂无数据"}`
          }
        },
        { tag: "hr" },
        {
          tag: "div",
          text: {
            tag: "lark_md",
            content: `**🏪 店铺销量概览**\n${shopSummary}`
          }
        },
        { tag: "hr" },
        {
          tag: "div",
          text: {
            tag: "lark_md",
            content: `**💡 行动建议**\n${(analysis.recommendations || []).map(r => "• " + r).join("\n")}`
          }
        }
      ]
    }
  };

  try {
    const res = await fetch(webhook, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body)
    });
    const data = await res.json();
    if (data.code === 0 || data.StatusCode === 0) {
      console.log("  ✅ 飞书推送成功！");
      return true;
    } else {
      console.error("  ❌ 飞书返回错误:", data.msg || data.StatusMessage || JSON.stringify(data));
      return false;
    }
  } catch (err) {
    console.error("  ❌ 飞书推送失败:", err.message);
    return false;
  }
}
