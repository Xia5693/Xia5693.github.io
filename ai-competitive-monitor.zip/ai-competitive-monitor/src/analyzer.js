/**
 * AI分析模块
 * 支持三种模式：Demo(模拟) / OpenAI / 通义千问
 */
import config from "../config.js";
import { generateDemoAnalysis } from "../data/mock-data.js";

const SYSTEM_PROMPT = `你是一位资深的电商供应链分析师。请根据提供的竞品监控数据，生成一份简洁专业的日报分析。

分析要求：
1. 总结当日市场整体动态（1-2句话）
2. 列出3-5个关键发现（用bullet points）
3. 给出2-3条可执行的建议
4. 标注值得关注的"异常信号"（价格异动、差评飙升、新品上架等）

输出格式要求：使用JSON格式，包含以下字段：
{
  "summary": "今日总览",
  "highlights": ["关键发现1", "关键发现2", ...],
  "recommendations": ["建议1", "建议2", ...],
  "alerts": ["异常信号1", ...]
}`;

function buildUserPrompt(snapshot) {
  let prompt = `日期：${snapshot.date}\n\n`;
  for (const shop of snapshot.shops) {
    prompt += `【${shop.name}】(${shop.level}，粉丝${shop.followers})\n`;
    for (const p of shop.products) {
      prompt += `  - ${p.name} | ¥${p.price} | 今日销量${p.todaySales}(${p.salesChange > 0 ? "+" : ""}${p.salesChange}%) | 评分${p.rating} | 差评率${p.negativeReviewRate}%`;
      if (p.events.length > 0) {
        prompt += ` | 事件：${p.events.map((e) => e.detail).join("、")}`;
      }
      prompt += "\n";
    }
    prompt += "\n";
  }
  prompt += "\n请基于以上数据生成分析报告。";
  return prompt;
}

async function callOpenAI(userPrompt) {
  const { apiKey, model } = config.openai;
  const response = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model,
      messages: [
        { role: "system", content: SYSTEM_PROMPT },
        { role: "user", content: userPrompt },
      ],
      temperature: 0.3,
      response_format: { type: "json_object" },
    }),
  });
  if (!response.ok) {
    const err = await response.text();
    throw new Error(`OpenAI API error: ${response.status} - ${err}`);
  }
  const data = await response.json();
  return JSON.parse(data.choices[0].message.content);
}

async function callTongyi(userPrompt) {
  const { apiKey, model, baseUrl } = config.tongyi;
  const response = await fetch(`${baseUrl}/chat/completions`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model,
      messages: [
        { role: "system", content: SYSTEM_PROMPT },
        { role: "user", content: userPrompt },
      ],
      temperature: 0.3,
    }),
  });
  if (!response.ok) {
    const err = await response.text();
    throw new Error(`Tongyi API error: ${response.status} - ${err}`);
  }
  const data = await response.json();
  // 通义千问可能返回markdown包裹的JSON，需要提取
  let content = data.choices[0].message.content;
  const jsonMatch = content.match(/\{[\s\S]*\}/);
  if (jsonMatch) content = jsonMatch[0];
  return JSON.parse(content);
}

/**
 * 主分析函数 - 根据配置自动选择AI模式
 */
export async function analyze(snapshot) {
  const mode = config.aiMode;

  if (mode === "demo") {
    console.log("  📊 [Demo模式] 使用内置规则生成分析...");
    // 模拟一点延迟，让体验更真实
    await new Promise((r) => setTimeout(r, 500));
    return generateDemoAnalysis(snapshot);
  }

  const userPrompt = buildUserPrompt(snapshot);

  if (mode === "openai") {
    if (!config.openai.apiKey) throw new Error("请设置 OPENAI_API_KEY 环境变量");
    console.log("  🤖 [OpenAI模式] 调用GPT分析中...");
    return await callOpenAI(userPrompt);
  }

  if (mode === "tongyi") {
    if (!config.tongyi.apiKey) throw new Error("请设置 DASHSCOPE_API_KEY 环境变量");
    console.log("  🤖 [通义千问模式] 调用Qwen分析中...");
    return await callTongyi(userPrompt);
  }

  throw new Error(`未知的AI模式: ${mode}，请在config.js中设置 aiMode`);
}
